--
-- PostgreSQL database dump
--

\restrict DKCPbplGWpldXf1bnIFkqWz8PrEQYiL0OYf64S2VEbyZQ0edGbustinlHwwcEXv

-- Dumped from database version 17.6 (Debian 17.6-1.pgdg12+1)
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: comiket_lottery_app_db_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO comiket_lottery_app_db_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: entries; Type: TABLE; Schema: public; Owner: comiket_lottery_app_db_user
--

CREATE TABLE public.entries (
    id bigint NOT NULL,
    prize_id text,
    entry_number text NOT NULL,
    password text NOT NULL,
    is_winner boolean DEFAULT false
);


ALTER TABLE public.entries OWNER TO comiket_lottery_app_db_user;

--
-- Name: entries_id_seq; Type: SEQUENCE; Schema: public; Owner: comiket_lottery_app_db_user
--

CREATE SEQUENCE public.entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.entries_id_seq OWNER TO comiket_lottery_app_db_user;

--
-- Name: entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comiket_lottery_app_db_user
--

ALTER SEQUENCE public.entries_id_seq OWNED BY public.entries.id;


--
-- Name: prizes; Type: TABLE; Schema: public; Owner: comiket_lottery_app_db_user
--

CREATE TABLE public.prizes (
    id text NOT NULL,
    name text NOT NULL,
    result_time_jst text,
    publish_time_utc timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.prizes OWNER TO comiket_lottery_app_db_user;

--
-- Name: entries id; Type: DEFAULT; Schema: public; Owner: comiket_lottery_app_db_user
--

ALTER TABLE ONLY public.entries ALTER COLUMN id SET DEFAULT nextval('public.entries_id_seq'::regclass);


--
-- Data for Name: entries; Type: TABLE DATA; Schema: public; Owner: comiket_lottery_app_db_user
--

COPY public.entries (id, prize_id, entry_number, password, is_winner) FROM stdin;
1	A001	001	1234	t
2	A001	002	5678	f
\.


--
-- Data for Name: prizes; Type: TABLE DATA; Schema: public; Owner: comiket_lottery_app_db_user
--

COPY public.prizes (id, name, result_time_jst, publish_time_utc, created_at, updated_at) FROM stdin;
A001	サンプル賞品A	2025-08-20 12:00	2025-08-20 03:00:00+00	2025-08-18 03:24:11.117654+00	2025-08-18 03:24:11.117654+00
\.


--
-- Name: entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comiket_lottery_app_db_user
--

SELECT pg_catalog.setval('public.entries_id_seq', 2, true);


--
-- Name: entries entries_pkey; Type: CONSTRAINT; Schema: public; Owner: comiket_lottery_app_db_user
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT entries_pkey PRIMARY KEY (id);


--
-- Name: entries entries_prize_id_entry_number_key; Type: CONSTRAINT; Schema: public; Owner: comiket_lottery_app_db_user
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT entries_prize_id_entry_number_key UNIQUE (prize_id, entry_number);


--
-- Name: prizes prizes_pkey; Type: CONSTRAINT; Schema: public; Owner: comiket_lottery_app_db_user
--

ALTER TABLE ONLY public.prizes
    ADD CONSTRAINT prizes_pkey PRIMARY KEY (id);


--
-- Name: entries entries_prize_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comiket_lottery_app_db_user
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT entries_prize_id_fkey FOREIGN KEY (prize_id) REFERENCES public.prizes(id) ON DELETE CASCADE;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON SEQUENCES TO comiket_lottery_app_db_user;


--
-- Name: DEFAULT PRIVILEGES FOR TYPES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TYPES TO comiket_lottery_app_db_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON FUNCTIONS TO comiket_lottery_app_db_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TABLES TO comiket_lottery_app_db_user;


--
-- PostgreSQL database dump complete
--

\unrestrict DKCPbplGWpldXf1bnIFkqWz8PrEQYiL0OYf64S2VEbyZQ0edGbustinlHwwcEXv

